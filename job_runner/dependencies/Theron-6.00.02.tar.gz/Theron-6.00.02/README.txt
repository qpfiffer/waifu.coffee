
Welcome to Theron!

Please see the included file LICENSE.txt for licensing information.

See the included HTML documentation in the /Docs folder for more information.
If the documentation is missing from your distribution, you can find it online
at http://www.theron-library.com

If you have any questions, feedback or bug reports, please send them to
me at ash@ashtonmason.net

Ashton Mason
