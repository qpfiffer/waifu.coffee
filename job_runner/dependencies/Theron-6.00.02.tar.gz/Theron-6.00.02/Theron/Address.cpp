// Copyright (C) by Ashton Mason. See LICENSE.txt for licensing information.


#include <Theron/Address.h>


namespace Theron
{


Address Address::smNullAddress;


} // namespace Theron

